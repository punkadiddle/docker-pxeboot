#ifndef _X86_64_LINUX_API_H
#define _X86_64_LINUX_API_H

#define __SYSCALL_mmap __NR_mmap

#endif /* _X86_64_LINUX_API_H */
