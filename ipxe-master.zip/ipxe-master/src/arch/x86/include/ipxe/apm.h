#ifndef _IPXE_APM_H
#define _IPXE_APM_H

/** @file
 *
 * Advanced Power Management
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

extern int apm_poweroff ( void );

#endif /* _IPXE_APM_H */
