#ifndef _BITS_UMALLOC_H
#define _BITS_UMALLOC_H

/** @file
 *
 * ARM-specific user memory allocation API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#endif /* _BITS_UMALLOC_H */
