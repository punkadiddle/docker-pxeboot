#ifndef _BITS_SMBIOS_H
#define _BITS_SMBIOS_H

/** @file
 *
 * ARM-specific SMBIOS API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#endif /* _BITS_SMBIOS_H */
